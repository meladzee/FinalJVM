module com.example.nimushifinal {
    requires javafx.controls;
    requires javafx.fxml;
    requires static lombok;
    requires java.sql;
    requires mysql.connector.j;


    opens com.example.nimushifinal to javafx.fxml;
    exports com.example.nimushifinal;
}