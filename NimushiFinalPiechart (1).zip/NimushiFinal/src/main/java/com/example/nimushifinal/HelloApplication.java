package com.example.nimushifinal;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import racminda.Product;

import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class HelloApplication extends Application {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/productcompany";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private GridPane formPane;
    private PieChart pieChart;

    @Override
    public void start(Stage stage) throws Exception {
        formPane = new GridPane();
        formPane.setVgap(10);

        Label nameLabel = new Label("Name");
        Label priceLabel = new Label("Price");
        Label quantityLabel = new Label("Quantity");
        TextField nameTextField = new TextField();
        TextField priceTextField = new TextField();
        TextField quantityTextField = new TextField();

        Button addButton = new Button("Add Record");

        addButton.setOnAction(actionEvent -> {
            String name = nameTextField.getText();
            int price = Integer.parseInt(priceTextField.getText());
            int quantity = Integer.parseInt(quantityTextField.getText());

            try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String selectQuery = "SELECT quantity FROM product WHERE name = ?";
                PreparedStatement selectStatement = connection.prepareStatement(selectQuery);
                selectStatement.setString(1, name);
                ResultSet resultSet = selectStatement.executeQuery();

                if (resultSet.next()) {
                    int existingQuantity = resultSet.getInt("quantity");
                    quantity += existingQuantity; // Increase the quantity
                    String updateQuery = "UPDATE product SET quantity = ? WHERE name = ?";
                    PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                    updateStatement.setInt(1, quantity);
                    updateStatement.setString(2, name);
                    updateStatement.executeUpdate();
                    updateStatement.close();
                } else {
                    Product product = new Product(name, price, quantity);
                    String insertQuery = "INSERT INTO product (name, price, quantity) VALUES (?, ?, ?)";
                    PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
                    insertStatement.setString(1, product.getName());
                    insertStatement.setInt(2, product.getPrice());
                    insertStatement.setInt(3, product.getQuantity());
                    insertStatement.executeUpdate();
                    insertStatement.close();
                }

                ObservableList<Product> newData = fetchDataFromDatabase();
                updatePieChart(newData);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            System.out.println("Name: " + name + ", Price: " + price + ", Quantity: " + quantity);
        });

        formPane.addRow(0, nameLabel, nameTextField);
        formPane.addRow(1, priceLabel, priceTextField);
        formPane.addRow(2, quantityLabel, quantityTextField);
        formPane.addRow(3, addButton);

        ObservableList<Product> initialData = fetchDataFromDatabase();
        pieChart = createPieChart(initialData);
        pieChart.setTitle("Product Quantities");

        VBox root = new VBox(20);
        root.getChildren().addAll(formPane, pieChart);
        root.setSpacing(20);
        root.setPadding(new javafx.geometry.Insets(20));

        Scene scene = new Scene(root, 600, 600);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    private ObservableList<Product> fetchDataFromDatabase() {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String selectQuery = "SELECT name, price, quantity FROM product";
            PreparedStatement statement = connection.prepareStatement(selectQuery);
            ResultSet resultSet = statement.executeQuery();

            ObservableList<Product> productList = FXCollections.observableArrayList();
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                int price = resultSet.getInt("price");
                int quantity = resultSet.getInt("quantity");
                Product product = new Product(name, price, quantity);
                productList.add(product);
            }

            return productList;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return FXCollections.emptyObservableList();
    }

    private PieChart createPieChart(ObservableList<Product> products) {
        Map<String, Integer> productQuantities = new HashMap<>();
        for (Product product : products) {
            String name = product.getName();
            int quantity = product.getQuantity();
            productQuantities.put(name, quantity);
        }

        List<PieChart.Data> pieChartData = productQuantities.entrySet().stream()
                .map(entry -> new PieChart.Data(entry.getKey() + " (" + entry.getValue() + ")", entry.getValue()))
                .collect(Collectors.toList());

        return new PieChart(FXCollections.observableArrayList(pieChartData));
    }

    private void updatePieChart(ObservableList<Product> products) {
        ObservableList<PieChart.Data> pieChartData = createPieChart(products).getData();
        pieChart.setData(pieChartData);
    }

    public static void main(String[] args) {
        launch();
    }
}
